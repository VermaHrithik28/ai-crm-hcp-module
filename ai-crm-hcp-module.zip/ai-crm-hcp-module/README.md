# AI-First CRM — HCP Module: Log Interaction Screen

An AI-first "Log HCP Interaction" screen for pharma field reps. Reps can log
interactions with healthcare professionals (HCPs) either through a structured
form or a conversational chat interface powered by a LangGraph agent — both
stay in sync.

## Architecture

```
┌──────────────┐      HTTP       ┌──────────────────┐        ┌────────────┐
│   React UI   │ ───────────────▶│   FastAPI backend │──────▶ │  Postgres  │
│ (Redux state)│ ◀─────────────── │  (REST + /agent)  │◀────── │  Database  │
└──────────────┘                 └─────────┬─────────┘        └────────────┘
                                            │
                                            ▼
                                 ┌────────────────────┐
                                 │   LangGraph agent    │
                                 │ router → tools → reply│
                                 └──────────┬─────────┘
                                            │
                                            ▼
                                   Groq (gemma2-9b-it)
```

- **Frontend**: React + Redux Toolkit. Left pane is the structured form
  (`InteractionForm.jsx`), right pane is the chat assistant (`ChatPanel.jsx`).
  When the agent logs or edits an interaction via chat, the response is
  dispatched into Redux (`hydrateFromAgent`) so the form auto-populates live.
- **Backend**: FastAPI. `/api/interactions` is a standard CRUD path for the
  form. `/api/agent/chat` runs the LangGraph agent for the conversational path.
- **Agent**: LangGraph `StateGraph` with a router node (LLM decides which
  tool to call), a `ToolNode` that executes it, and a responder node that
  turns the tool result into a natural-language confirmation.
- **LLM**: Groq's `gemma2-9b-it` (fast, low-latency, good enough for entity
  extraction and short classification tasks in this flow).
  `llama-3.3-70b-versatile` is wired in as a configurable fallback via
  `FALLBACK_LLM_MODEL` for cases needing stronger reasoning.
- **Database**: Postgres via SQLAlchemy (swap `DATABASE_URL` for a SQLite
  path if you want to run without installing Postgres locally).

## The 5 LangGraph tools

| Tool | Purpose |
|---|---|
| `log_interaction` | Takes free text, uses the LLM to extract HCP name, sentiment, topics, materials/samples, and outcomes, then inserts a new DB row. |
| `edit_interaction` | Takes an interaction ID + a natural-language change request, diffs it against the current record, and updates only the affected fields. |
| `search_hcp` | Fuzzy name lookup against a mock HCP master table (specialty, hospital). |
| `suggest_follow_ups` | Given topics/outcomes, asks the LLM for 2–3 concrete next-step suggestions (mirrors the "AI Suggested Follow-ups" panel in the mockup). |
| `summarize_voice_note` | Turns a transcribed voice note into structured fields — pairs with the "Summarize from Voice Note" button in the UI. |

## Role of the LangGraph agent

The agent sits between the rep's natural language (typed or transcribed) and
the structured CRM schema. It classifies intent, calls the right tool,
and returns both a structured payload (for the form) and a short conversational
confirmation (for the chat), so a rep never has to touch the form directly
if they don't want to.

## Setup

### Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env   # then fill in GROQ_API_KEY and DATABASE_URL
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev   # runs on http://localhost:3000, proxies /api to :8000
```

### Environment variables (`backend/.env`)
```
GROQ_API_KEY=your_groq_api_key_here
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/hcp_crm
LLM_MODEL=gemma2-9b-it
FALLBACK_LLM_MODEL=llama-3.3-70b-versatile
```

> No Postgres handy? Open `backend/app/database.py` and uncomment the SQLite
> `DATABASE_URL` line for a zero-config local run.

## Repo structure
```
backend/
  app/
    agent/        # LangGraph graph + 5 tools
    models/        # SQLAlchemy models
    schemas/        # Pydantic request/response schemas
    routes/        # /api/interactions, /api/agent
    main.py
    database.py
  requirements.txt
frontend/
  src/
    components/    # InteractionForm, ChatPanel
    store/         # Redux slices
    api/           # backend client
    App.jsx, main.jsx, styles.css
```
