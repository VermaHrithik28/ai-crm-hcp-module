import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  id: null,
  hcp_name: '',
  interaction_type: 'Meeting',
  date: '',
  time: '',
  attendees: '',
  topics_discussed: '',
  materials_shared: [],
  samples_distributed: [],
  sentiment: 'Neutral',
  outcomes: '',
  follow_up_actions: '',
  ai_suggested_follow_ups: [],
};

const interactionSlice = createSlice({
  name: 'interaction',
  initialState,
  reducers: {
    setField: (state, action) => {
      const { field, value } = action.payload;
      state[field] = value;
    },
    // Called when the chat agent logs or edits an interaction -
    // this is what keeps the form and chat interface in sync.
    hydrateFromAgent: (state, action) => {
      return { ...state, ...action.payload };
    },
    resetInteraction: () => initialState,
  },
});

export const { setField, hydrateFromAgent, resetInteraction } = interactionSlice.actions;
export default interactionSlice.reducer;
