import InteractionForm from './components/InteractionForm';
import ChatPanel from './components/ChatPanel';
import './styles.css';

export default function App() {
  return (
    <div className="app-shell">
      <h1>Log HCP Interaction</h1>
      <div className="split-layout">
        <InteractionForm />
        <ChatPanel />
      </div>
    </div>
  );
}
