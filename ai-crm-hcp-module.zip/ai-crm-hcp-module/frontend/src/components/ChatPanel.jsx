import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addMessage, setLoading } from '../store/chatSlice';
import { hydrateFromAgent } from '../store/interactionSlice';
import { sendChatMessage } from '../api/client';

const SESSION_ID = 'demo-session-1'; // In production, generate per logged-in rep session

export default function ChatPanel() {
  const dispatch = useDispatch();
  const { messages, loading } = useSelector((state) => state.chat);
  const [draft, setDraft] = useState('');

  const handleSend = async () => {
    if (!draft.trim()) return;
    const text = draft.trim();
    setDraft('');
    dispatch(addMessage({ role: 'user', text }));
    dispatch(setLoading(true));
    try {
      const result = await sendChatMessage(SESSION_ID, text);
      dispatch(addMessage({ role: 'assistant', text: result.reply }));
      // If the agent's tool call produced structured interaction data,
      // push it into the form so both interfaces stay in sync.
      if (result.interaction) {
        dispatch(hydrateFromAgent(result.interaction));
      }
    } catch (err) {
      dispatch(addMessage({ role: 'assistant', text: `Error: ${err.message}` }));
    } finally {
      dispatch(setLoading(false));
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="panel chat-panel">
      <h2>🤖 AI Assistant</h2>
      <p className="muted small">Log interaction via chat</p>

      <div className="chat-messages">
        {messages.map((m, i) => (
          <div key={i} className={`chat-bubble ${m.role}`}>{m.text}</div>
        ))}
        {loading && <div className="chat-bubble assistant">Thinking...</div>}
      </div>

      <div className="chat-input-row">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Describe interaction..."
        />
        <button onClick={handleSend} disabled={loading}>Log</button>
      </div>
    </div>
  );
}
