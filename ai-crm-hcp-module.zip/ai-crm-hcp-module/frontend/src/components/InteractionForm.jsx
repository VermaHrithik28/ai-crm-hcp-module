import { useDispatch, useSelector } from 'react-redux';
import { setField } from '../store/interactionSlice';

const SENTIMENTS = ['Positive', 'Neutral', 'Negative'];

export default function InteractionForm() {
  const dispatch = useDispatch();
  const interaction = useSelector((state) => state.interaction);

  const update = (field) => (e) => dispatch(setField({ field, value: e.target.value }));

  return (
    <div className="panel form-panel">
      <h2>Interaction Details</h2>

      <div className="row">
        <label>
          HCP Name
          <input value={interaction.hcp_name} onChange={update('hcp_name')} placeholder="Search or select HCP..." />
        </label>
        <label>
          Interaction Type
          <select value={interaction.interaction_type} onChange={update('interaction_type')}>
            <option>Meeting</option>
            <option>Call</option>
            <option>Email</option>
            <option>Conference</option>
          </select>
        </label>
      </div>

      <div className="row">
        <label>
          Date
          <input type="date" value={interaction.date} onChange={update('date')} />
        </label>
        <label>
          Time
          <input type="time" value={interaction.time} onChange={update('time')} />
        </label>
      </div>

      <label className="full">
        Attendees
        <input value={interaction.attendees} onChange={update('attendees')} placeholder="Enter names or search..." />
      </label>

      <label className="full">
        Topics Discussed
        <textarea value={interaction.topics_discussed} onChange={update('topics_discussed')} placeholder="Enter key discussion points..." />
      </label>
      <button className="ghost-btn">🎙 Summarize from Voice Note (Requires Consent)</button>

      <div className="full">
        <span className="section-label">Materials Shared / Samples Distributed</span>
        <div className="chip-row">
          {interaction.materials_shared.length === 0 ? <span className="muted">No materials added</span>
            : interaction.materials_shared.map((m) => <span key={m} className="chip">{m}</span>)}
        </div>
        <div className="chip-row">
          {interaction.samples_distributed.length === 0 ? <span className="muted">No samples added</span>
            : interaction.samples_distributed.map((s) => <span key={s} className="chip">{s}</span>)}
        </div>
      </div>

      <div className="full">
        <span className="section-label">Observed/Inferred HCP Sentiment</span>
        <div className="sentiment-row">
          {SENTIMENTS.map((s) => (
            <label key={s} className="radio-inline">
              <input type="radio" name="sentiment" checked={interaction.sentiment === s}
                onChange={() => dispatch(setField({ field: 'sentiment', value: s }))} />
              {s}
            </label>
          ))}
        </div>
      </div>

      <label className="full">
        Outcomes
        <textarea value={interaction.outcomes} onChange={update('outcomes')} placeholder="Key outcomes or agreements..." />
      </label>

      <label className="full">
        Follow-up Actions
        <textarea value={interaction.follow_up_actions} onChange={update('follow_up_actions')} placeholder="Enter next steps or tasks..." />
      </label>

      {interaction.ai_suggested_follow_ups.length > 0 && (
        <div className="full ai-suggestions">
          <span className="section-label">AI Suggested Follow-ups</span>
          <ul>
            {interaction.ai_suggested_follow_ups.map((s, i) => <li key={i}>+ {s}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}
