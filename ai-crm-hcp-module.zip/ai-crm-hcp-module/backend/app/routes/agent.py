from fastapi import APIRouter

from app.agent.graph import run_agent
from app.schemas.interaction import ChatRequest, ChatResponse

router = APIRouter(prefix="/api/agent", tags=["agent"])


@router.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    result = run_agent(payload.session_id, payload.message)
    return ChatResponse(
        reply=result["reply"],
        interaction=result.get("interaction"),
        tool_used=result.get("tool_used"),
    )
