import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Text, JSON
from app.database import Base


def gen_uuid():
    return str(uuid.uuid4())


class Interaction(Base):
    __tablename__ = "interactions"

    id = Column(String, primary_key=True, default=gen_uuid)
    hcp_name = Column(String, nullable=False)
    interaction_type = Column(String, default="Meeting")
    date = Column(String, nullable=True)          # YYYY-MM-DD
    time = Column(String, nullable=True)           # HH:MM
    attendees = Column(String, nullable=True)
    topics_discussed = Column(Text, nullable=True)
    materials_shared = Column(JSON, default=list)   # list[str]
    samples_distributed = Column(JSON, default=list)  # list[str]
    sentiment = Column(String, default="Neutral")   # Positive | Neutral | Negative
    outcomes = Column(Text, nullable=True)
    follow_up_actions = Column(Text, nullable=True)
    ai_suggested_follow_ups = Column(JSON, default=list)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
