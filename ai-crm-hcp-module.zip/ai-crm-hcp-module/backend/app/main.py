from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app.models import interaction  # noqa: F401 - ensures model is registered before create_all
from app.routes import interactions, agent

Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI-First CRM - HCP Module API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(interactions.router)
app.include_router(agent.router)


@app.get("/")
def health_check():
    return {"status": "ok", "service": "hcp-crm-backend"}
