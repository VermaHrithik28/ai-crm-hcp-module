"""
LangGraph Agent Tools for the HCP Log Interaction module.

Each tool is a plain Python function decorated with @tool so LangGraph's
ToolNode can call it directly. Tools that need LLM reasoning (entity
extraction, summarization, follow-up suggestion) call a shared Groq client.
"""
import json
import os
from typing import List, Optional

from langchain_core.tools import tool
from langchain_groq import ChatGroq
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.interaction import Interaction

MODEL = os.getenv("LLM_MODEL", "gemma2-9b-it")
FALLBACK_MODEL = os.getenv("FALLBACK_LLM_MODEL", "llama-3.3-70b-versatile")

_llm = ChatGroq(model=MODEL, temperature=0)

# Mock HCP master data - in production this would be a real table synced from an MDM system
MOCK_HCP_DB = [
    {"name": "Dr. Sharma", "specialty": "Oncology", "hospital": "Fortis"},
    {"name": "Dr. Smith", "specialty": "Cardiology", "hospital": "Apollo"},
    {"name": "Dr. Mehta", "specialty": "Neurology", "hospital": "Max Healthcare"},
]

EXTRACTION_PROMPT = """You are a CRM data-extraction assistant for pharma field reps.
Extract structured fields from the free-text interaction note below.
Return ONLY valid JSON, no markdown fences, no preamble, matching this schema:
{{
  "hcp_name": string,
  "interaction_type": one of ["Meeting","Call","Email","Conference"],
  "topics_discussed": string,
  "materials_shared": [string],
  "samples_distributed": [string],
  "sentiment": one of ["Positive","Neutral","Negative"],
  "outcomes": string
}}
If a field isn't mentioned, use an empty string or empty list.

Text: {text}
"""


def _extract_json(raw: str) -> dict:
    """Best-effort strip of markdown fences before json.loads."""
    cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    return json.loads(cleaned)


@tool
def log_interaction(free_text: str) -> str:
    """Log a new HCP interaction from a free-text description.
    Uses the LLM to extract entities (HCP name, sentiment, topics, materials,
    samples, outcomes) and inserts a new row into the interactions table.
    Returns the created interaction as JSON.
    """
    prompt = EXTRACTION_PROMPT.format(text=free_text)
    response = _llm.invoke(prompt)
    try:
        data = _extract_json(response.content)
    except Exception:
        data = {"hcp_name": "Unknown", "interaction_type": "Meeting", "topics_discussed": free_text,
                "materials_shared": [], "samples_distributed": [], "sentiment": "Neutral", "outcomes": ""}

    db: Session = SessionLocal()
    try:
        record = Interaction(
            hcp_name=data.get("hcp_name") or "Unknown",
            interaction_type=data.get("interaction_type") or "Meeting",
            topics_discussed=data.get("topics_discussed", ""),
            materials_shared=data.get("materials_shared", []),
            samples_distributed=data.get("samples_distributed", []),
            sentiment=data.get("sentiment", "Neutral"),
            outcomes=data.get("outcomes", ""),
        )
        db.add(record)
        db.commit()
        db.refresh(record)
        return json.dumps({
            "id": record.id, "hcp_name": record.hcp_name, "interaction_type": record.interaction_type,
            "topics_discussed": record.topics_discussed, "materials_shared": record.materials_shared,
            "samples_distributed": record.samples_distributed, "sentiment": record.sentiment,
            "outcomes": record.outcomes,
        })
    finally:
        db.close()


@tool
def edit_interaction(interaction_id: str, change_description: str) -> str:
    """Edit an existing logged interaction using a natural-language change
    description (e.g. 'change sentiment to positive' or 'add brochure to materials shared').
    Diffs the requested change against the current record and updates only
    the relevant field(s). Returns the updated interaction as JSON, or an
    error message if the interaction id is not found.
    """
    db: Session = SessionLocal()
    try:
        record = db.query(Interaction).filter(Interaction.id == interaction_id).first()
        if not record:
            return json.dumps({"error": f"No interaction found with id {interaction_id}"})

        current_state = {
            "hcp_name": record.hcp_name, "interaction_type": record.interaction_type,
            "topics_discussed": record.topics_discussed, "materials_shared": record.materials_shared,
            "samples_distributed": record.samples_distributed, "sentiment": record.sentiment,
            "outcomes": record.outcomes, "follow_up_actions": record.follow_up_actions,
        }
        prompt = f"""Current interaction record (JSON): {json.dumps(current_state)}
Requested change: "{change_description}"
Return ONLY the JSON fields that should change, no markdown fences, no preamble.
Only include keys that need updating."""
        response = _llm.invoke(prompt)
        updates = _extract_json(response.content)

        for key, value in updates.items():
            if hasattr(record, key):
                setattr(record, key, value)
        db.commit()
        db.refresh(record)
        return json.dumps({
            "id": record.id, "hcp_name": record.hcp_name, "sentiment": record.sentiment,
            "topics_discussed": record.topics_discussed, "outcomes": record.outcomes,
            "follow_up_actions": record.follow_up_actions, "updated_fields": list(updates.keys()),
        })
    finally:
        db.close()


@tool
def search_hcp(query: str) -> str:
    """Search the HCP master list by name (fuzzy, case-insensitive substring match).
    Returns matching HCPs with specialty and hospital as JSON.
    """
    q = query.lower()
    matches = [h for h in MOCK_HCP_DB if q in h["name"].lower()]
    return json.dumps({"matches": matches})


@tool
def suggest_follow_ups(topics_discussed: str, outcomes: str) -> str:
    """Suggest 2-3 concrete next-step follow-up actions for a rep based on the
    topics discussed and outcomes of an HCP interaction. Returns a JSON list
    of short, actionable suggestions.
    """
    prompt = f"""Based on this HCP interaction, suggest 2-3 short, concrete follow-up
actions a pharma field rep should take next. Return ONLY a JSON array of strings,
no markdown fences, no preamble.

Topics discussed: {topics_discussed}
Outcomes: {outcomes}
"""
    response = _llm.invoke(prompt)
    try:
        suggestions = _extract_json(response.content)
        if not isinstance(suggestions, list):
            suggestions = [str(suggestions)]
    except Exception:
        suggestions = ["Schedule a follow-up meeting", "Share relevant clinical materials"]
    return json.dumps({"suggestions": suggestions})


@tool
def summarize_voice_note(transcribed_text: str) -> str:
    """Summarize a transcribed voice note (assumes upstream speech-to-text,
    e.g. browser Web Speech API or Whisper) into structured interaction fields:
    topics, sentiment, and materials/samples mentioned. Returns JSON.
    Requires the rep's consent to have been captured client-side before this
    tool is invoked (see 'Summarize from Voice Note (Requires Consent)' in the UI).
    """
    prompt = EXTRACTION_PROMPT.format(text=transcribed_text)
    response = _llm.invoke(prompt)
    try:
        data = _extract_json(response.content)
    except Exception:
        data = {"topics_discussed": transcribed_text, "sentiment": "Neutral",
                "materials_shared": [], "samples_distributed": []}
    return json.dumps(data)


ALL_TOOLS = [log_interaction, edit_interaction, search_hcp, suggest_follow_ups, summarize_voice_note]
