"""
LangGraph agent for the HCP Log Interaction Screen.

Graph shape:

    START -> router_node -> tool_node -> responder_node -> END

- router_node: the LLM (bound with tools) decides which tool(s) to call
  based on the conversation so far, or answers directly if no tool is needed.
- tool_node: executes the chosen tool(s) via LangGraph's prebuilt ToolNode.
- responder_node: turns the raw tool JSON output into a short, natural-language
  confirmation for the rep, and extracts the structured interaction payload
  so the frontend can auto-populate the form.
"""
import json
import os
from typing import Annotated, Optional, TypedDict

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

from app.agent.tools import ALL_TOOLS

MODEL = os.getenv("LLM_MODEL", "gemma2-9b-it")

SYSTEM_PROMPT = """You are the AI assistant embedded in a pharma CRM's "Log HCP Interaction" screen.
Field reps describe interactions with healthcare professionals (HCPs) in plain language,
via chat, instead of filling out the structured form manually.

You have 5 tools:
- log_interaction: create a new interaction record from free text
- edit_interaction: modify an existing record (needs an interaction_id)
- search_hcp: look up an HCP by name
- suggest_follow_ups: propose next-step actions
- summarize_voice_note: turn a transcribed voice note into structured fields

Decide which tool (if any) fits the rep's message and call it. If the rep is
just asking a question and no tool applies, answer directly and briefly.
"""


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    last_interaction: Optional[dict]
    tool_used: Optional[str]


llm_with_tools = ChatGroq(model=MODEL, temperature=0).bind_tools(ALL_TOOLS)
tool_node = ToolNode(ALL_TOOLS)


def router_node(state: AgentState) -> AgentState:
    messages = state["messages"]
    if not any(isinstance(m, SystemMessage) for m in messages):
        messages = [SystemMessage(content=SYSTEM_PROMPT)] + messages
    ai_message = llm_with_tools.invoke(messages)
    return {"messages": [ai_message]}


def should_continue(state: AgentState) -> str:
    last = state["messages"][-1]
    if getattr(last, "tool_calls", None):
        return "tools"
    return "responder"


def after_tools_node(state: AgentState) -> AgentState:
    """Pull structured JSON out of the most recent ToolMessage so the API
    layer can hand it back to the frontend for form auto-population."""
    last_interaction = None
    tool_used = None
    for m in reversed(state["messages"]):
        if isinstance(m, ToolMessage):
            tool_used = m.name
            try:
                parsed = json.loads(m.content)
                if isinstance(parsed, dict) and "error" not in parsed:
                    last_interaction = parsed
            except Exception:
                pass
            break
    return {"last_interaction": last_interaction, "tool_used": tool_used}


def responder_node(state: AgentState) -> AgentState:
    """Ask the LLM for a short natural-language confirmation given the full
    message history (including any tool results)."""
    reply = llm_with_tools.invoke(state["messages"])
    return {"messages": [reply]}


def build_agent_graph():
    graph = StateGraph(AgentState)
    graph.add_node("router", router_node)
    graph.add_node("tools", tool_node)
    graph.add_node("after_tools", after_tools_node)
    graph.add_node("responder", responder_node)

    graph.set_entry_point("router")
    graph.add_conditional_edges("router", should_continue, {"tools": "tools", "responder": "responder"})
    graph.add_edge("tools", "after_tools")
    graph.add_edge("after_tools", "responder")
    graph.add_edge("responder", END)

    return graph.compile()


agent_graph = build_agent_graph()


def run_agent(session_id: str, message: str) -> dict:
    """Entry point used by the /api/agent/chat route."""
    result = agent_graph.invoke({
        "messages": [HumanMessage(content=message)],
        "last_interaction": None,
        "tool_used": None,
    })
    final_ai_message = result["messages"][-1]
    return {
        "reply": final_ai_message.content,
        "interaction": result.get("last_interaction"),
        "tool_used": result.get("tool_used"),
    }
